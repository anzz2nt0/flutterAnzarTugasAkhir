final Map<String, List<Map<String, String>>> foodData = {
  "Chicken Katsu": [
    {"name": "Katsu Original", "price": "25000"},
    {"name": "Katsu Spicy", "price": "27000"},
  ],
  "Chicken Teriyaki": [
    {"name": "Teriyaki Rice", "price": "30000"},
    {"name": "Teriyaki Bento", "price": "35000"},
  ],
  "Fried Chicken": [
    {"name": "Fried Chicken", "price": "20000"},
  ],
  "Salad": [
    {"name": "Greek Salad", "price": "22000"},
  ],
  "Beef Bulgogi": [
    {"name": "Bulgogi Rice", "price": "40000"},
  ],
  "Beef Steak": [
    {"name": "Steak Medium", "price": "55000"},
  ],
  "Ice Water": [
    {"name": "Air Es", "price": "5000"},
  ],
  "Lemonade": [
    {"name": "Lemonade", "price": "8000"},
  ],
  "Fruit Platter": [
    {"name": "Mix Fruit", "price": "18000"},
  ],
  "Iced Tea": [
    {"name": "Es Teh", "price": "6000"},
  ],
};
