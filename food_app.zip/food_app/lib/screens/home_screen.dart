import 'package:flutter/material.dart';
import '../widgets/category_card.dart';
import 'meal_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  final List<String> categories = const [
    "Chicken Katsu",
    "Chicken Teriyaki",
    "Fried Chicken",
    "Salad",
    "Beef Bulgogi",
    "Beef Steak",
    "Ice Water",
    "Lemonade",
    "Fruit Platter",
    "Iced Tea"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pick Your Category"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.builder(
          itemCount: categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.2,
          ),
          itemBuilder: (context, index) {
            return CategoryCard(
              title: categories[index],
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => MealScreen(category: categories[index]),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
